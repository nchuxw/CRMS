/*==============================================================*/
/* Database name:  CRMS                                         */
/* DBMS name:      Microsoft SQL Server 2012                    */
/* Created on:     2019/1/9 9:21:56                             */
/*==============================================================*/


drop database CRMS
go

/*==============================================================*/
/* Database: CRMS                                               */
/*==============================================================*/
create database CRMS
go

use CRMS
go

/*==============================================================*/
/* Table: class_uselog                                          */
/*==============================================================*/
create table class_uselog (
   class_id             numeric              not null,
   start_time           datetime             not null,
   end_time             datetime             null,
   room_id              numeric              null,
   constraint PK_CLASS_USELOG primary key (class_id, start_time)
)
go

if exists (select 1 from  sys.extended_properties
           where major_id = object_id('class_uselog') and minor_id = 0)
begin 
   declare @CurrentUser sysname 
select @CurrentUser = user_name() 
execute sp_dropextendedproperty 'MS_Description',  
   'user', @CurrentUser, 'table', 'class_uselog' 
 
end 


select @CurrentUser = user_name() 
execute sp_addextendedproperty 'MS_Description',  
   '�༶ʹ����־', 
   'user', @CurrentUser, 'table', 'class_uselog'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('class_uselog')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'class_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'class_uselog', 'column', 'class_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�༶id',
   'user', @CurrentUser, 'table', 'class_uselog', 'column', 'class_id'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('class_uselog')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'start_time')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'class_uselog', 'column', 'start_time'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��ʼ�ϻ�ʱ��',
   'user', @CurrentUser, 'table', 'class_uselog', 'column', 'start_time'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('class_uselog')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'end_time')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'class_uselog', 'column', 'end_time'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�ϻ�����ʱ��',
   'user', @CurrentUser, 'table', 'class_uselog', 'column', 'end_time'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('class_uselog')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'room_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'class_uselog', 'column', 'room_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����id',
   'user', @CurrentUser, 'table', 'class_uselog', 'column', 'room_id'
go

/*==============================================================*/
/* Table: computer                                              */
/*==============================================================*/
create table computer (
   com_id               numeric              identity,
   room_id              numeric              null,
   com_no               varchar(50)          null,
   satus                varchar(50)          null default '��ʹ��',
   layout_x             int                  null,
   layout_y             int                  null,
   constraint PK_COMPUTER primary key nonclustered (com_id),
   constraint AK_KEY_2_COMPUTER unique (room_id, com_no)
)
go

if exists (select 1 from  sys.extended_properties
           where major_id = object_id('computer') and minor_id = 0)
begin 
   declare @CurrentUser sysname 
select @CurrentUser = user_name() 
execute sp_dropextendedproperty 'MS_Description',  
   'user', @CurrentUser, 'table', 'computer' 
 
end 


select @CurrentUser = user_name() 
execute sp_addextendedproperty 'MS_Description',  
   '���Ա�', 
   'user', @CurrentUser, 'table', 'computer'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'com_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer', 'column', 'com_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����id����������',
   'user', @CurrentUser, 'table', 'computer', 'column', 'com_id'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'room_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer', 'column', 'room_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��������id',
   'user', @CurrentUser, 'table', 'computer', 'column', 'room_id'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'com_no')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer', 'column', 'com_no'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�����ڻ�����ı��',
   'user', @CurrentUser, 'table', 'computer', 'column', 'com_no'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'satus')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer', 'column', 'satus'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '״̬����ʹ��/����ʹ��/ά�ޣ�',
   'user', @CurrentUser, 'table', 'computer', 'column', 'satus'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'layout_x')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer', 'column', 'layout_x'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'λ��x����',
   'user', @CurrentUser, 'table', 'computer', 'column', 'layout_x'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'layout_y')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer', 'column', 'layout_y'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'λ��y����',
   'user', @CurrentUser, 'table', 'computer', 'column', 'layout_y'
go

/*==============================================================*/
/* Table: computer_room                                         */
/*==============================================================*/
create table computer_room (
   room_id              numeric              identity,
   department           varchar(50)          null,
   name                 varchar(50)          null,
   width                int                  null,
   height               int                  null,
   com_num              int                  null default 0
      constraint CKC_COM_NUM_COMPUTER check (com_num is null or (com_num >= 0)),
   usable_num           int                  null default 0
      constraint CKC_USABLE_NUM_COMPUTER check (usable_num is null or (usable_num >= 0)),
   unuse_time           varchar(50)          null,
   config               varchar(200)         null default '--',
   software             varchar(200)         null default '--',
   liabler              varchar(50)          null default '--',
   constraint PK_COMPUTER_ROOM primary key nonclustered (room_id),
   constraint AK_KEY_2_ROOM unique (department, name)
)
go

if exists (select 1 from  sys.extended_properties
           where major_id = object_id('computer_room') and minor_id = 0)
begin 
   declare @CurrentUser sysname 
select @CurrentUser = user_name() 
execute sp_dropextendedproperty 'MS_Description',  
   'user', @CurrentUser, 'table', 'computer_room' 
 
end 


select @CurrentUser = user_name() 
execute sp_addextendedproperty 'MS_Description',  
   '������', 
   'user', @CurrentUser, 'table', 'computer_room'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'room_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'room_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����id����������',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'room_id'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'department')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'department'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��������',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'department'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'name')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'name'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '������',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'name'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'width')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'width'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��������',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'width'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'height')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'height'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��������',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'height'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'com_num')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'com_num'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��������',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'com_num'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'usable_num')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'usable_num'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��ʹ�õĵ�������',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'usable_num'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'unuse_time')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'unuse_time'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����������ʱ��',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'unuse_time'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'config')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'config'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��������˵��',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'config'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'software')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'software'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��װ������˵��',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'software'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('computer_room')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'liabler')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'liabler'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����������',
   'user', @CurrentUser, 'table', 'computer_room', 'column', 'liabler'
go

/*==============================================================*/
/* Table: department                                            */
/*==============================================================*/
create table department (
   department           varchar(50)          not null,
   schedule             varchar(100)         null,
   course_num           int                  null,
   constraint PK_DEPARTMENT primary key (department)
)
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('department')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'department')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'department', 'column', 'department'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '������',
   'user', @CurrentUser, 'table', 'department', 'column', 'department'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('department')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'schedule')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'department', 'column', 'schedule'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��Ϣʱ��',
   'user', @CurrentUser, 'table', 'department', 'column', 'schedule'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('department')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'course_num')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'department', 'column', 'course_num'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'һ��Ŀγ�����',
   'user', @CurrentUser, 'table', 'department', 'column', 'course_num'
go

/*==============================================================*/
/* Table: login_log                                             */
/*==============================================================*/
create table login_log (
   user_id              numeric              not null,
   login_time           datetime             not null,
   logout_time          datetime             null,
   ip_address           varchar(50)          null,
   constraint PK_LOGIN_LOG primary key (user_id, login_time)
)
go

if exists (select 1 from  sys.extended_properties
           where major_id = object_id('login_log') and minor_id = 0)
begin 
   declare @CurrentUser sysname 
select @CurrentUser = user_name() 
execute sp_dropextendedproperty 'MS_Description',  
   'user', @CurrentUser, 'table', 'login_log' 
 
end 


select @CurrentUser = user_name() 
execute sp_addextendedproperty 'MS_Description',  
   '��¼��־��', 
   'user', @CurrentUser, 'table', 'login_log'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('login_log')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'user_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'login_log', 'column', 'user_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�û�id',
   'user', @CurrentUser, 'table', 'login_log', 'column', 'user_id'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('login_log')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'login_time')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'login_log', 'column', 'login_time'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��¼ʱ��',
   'user', @CurrentUser, 'table', 'login_log', 'column', 'login_time'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('login_log')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'logout_time')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'login_log', 'column', 'logout_time'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�ǳ�ʱ��',
   'user', @CurrentUser, 'table', 'login_log', 'column', 'logout_time'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('login_log')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'ip_address')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'login_log', 'column', 'ip_address'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'ip��ַ',
   'user', @CurrentUser, 'table', 'login_log', 'column', 'ip_address'
go

/*==============================================================*/
/* Table: tclass                                                */
/*==============================================================*/
create table tclass (
   class_id             numeric              identity,
   name                 varchar(50)          null,
   stu_num              int                  null default 0,
   min_period           int                  null default 0,
   department           varchar(50)          null,
   constraint PK_TCLASS primary key nonclustered (class_id),
   constraint AK_KEY_2_TCLASS unique (name, department)
)
go

if exists (select 1 from  sys.extended_properties
           where major_id = object_id('tclass') and minor_id = 0)
begin 
   declare @CurrentUser sysname 
select @CurrentUser = user_name() 
execute sp_dropextendedproperty 'MS_Description',  
   'user', @CurrentUser, 'table', 'tclass' 
 
end 


select @CurrentUser = user_name() 
execute sp_addextendedproperty 'MS_Description',  
   '�༶��', 
   'user', @CurrentUser, 'table', 'tclass'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tclass')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'class_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tclass', 'column', 'class_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�༶id����������',
   'user', @CurrentUser, 'table', 'tclass', 'column', 'class_id'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tclass')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'name')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tclass', 'column', 'name'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�༶��',
   'user', @CurrentUser, 'table', 'tclass', 'column', 'name'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tclass')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'stu_num')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tclass', 'column', 'stu_num'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'ѧ������',
   'user', @CurrentUser, 'table', 'tclass', 'column', 'stu_num'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tclass')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'min_period')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tclass', 'column', 'min_period'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�ϻ����ѧʱ',
   'user', @CurrentUser, 'table', 'tclass', 'column', 'min_period'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tclass')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'department')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tclass', 'column', 'department'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��������',
   'user', @CurrentUser, 'table', 'tclass', 'column', 'department'
go

/*==============================================================*/
/* Table: tuser                                                 */
/*==============================================================*/
create table tuser (
   user_id              numeric              identity,
   password             varchar(50)          not null,
   type                 varchar(20)          null,
   school_no            varchar(50)          null,
   name                 varchar(50)          null,
   class_id             numeric              null,
   department           varchar(50)          null,
   constraint PK_TUSER primary key nonclustered (user_id),
   constraint AK_KEY_2_TUSER unique (school_no, department)
)
go

if exists (select 1 from  sys.extended_properties
           where major_id = object_id('tuser') and minor_id = 0)
begin 
   declare @CurrentUser sysname 
select @CurrentUser = user_name() 
execute sp_dropextendedproperty 'MS_Description',  
   'user', @CurrentUser, 'table', 'tuser' 
 
end 


select @CurrentUser = user_name() 
execute sp_addextendedproperty 'MS_Description',  
   '�û���', 
   'user', @CurrentUser, 'table', 'tuser'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tuser')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'user_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tuser', 'column', 'user_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�û�id����������',
   'user', @CurrentUser, 'table', 'tuser', 'column', 'user_id'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tuser')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'password')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tuser', 'column', 'password'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����',
   'user', @CurrentUser, 'table', 'tuser', 'column', 'password'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tuser')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'type')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tuser', 'column', 'type'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�û�����',
   'user', @CurrentUser, 'table', 'tuser', 'column', 'type'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tuser')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'school_no')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tuser', 'column', 'school_no'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'ѧ��',
   'user', @CurrentUser, 'table', 'tuser', 'column', 'school_no'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tuser')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'name')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tuser', 'column', 'name'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�û���',
   'user', @CurrentUser, 'table', 'tuser', 'column', 'name'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tuser')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'class_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tuser', 'column', 'class_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�����༶',
   'user', @CurrentUser, 'table', 'tuser', 'column', 'class_id'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('tuser')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'department')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'tuser', 'column', 'department'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��������',
   'user', @CurrentUser, 'table', 'tuser', 'column', 'department'
go

/*==============================================================*/
/* Table: user_uselog                                           */
/*==============================================================*/
create table user_uselog (
   user_id              numeric              not null,
   start_time           datetime             not null,
   end_time             datetime             null,
   com_id               numeric              null,
   constraint PK_USER_USELOG primary key (user_id, start_time)
)
go

if exists (select 1 from  sys.extended_properties
           where major_id = object_id('user_uselog') and minor_id = 0)
begin 
   declare @CurrentUser sysname 
select @CurrentUser = user_name() 
execute sp_dropextendedproperty 'MS_Description',  
   'user', @CurrentUser, 'table', 'user_uselog' 
 
end 


select @CurrentUser = user_name() 
execute sp_addextendedproperty 'MS_Description',  
   'ѧ��ʹ����־', 
   'user', @CurrentUser, 'table', 'user_uselog'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('user_uselog')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'user_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'user_uselog', 'column', 'user_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�û�id',
   'user', @CurrentUser, 'table', 'user_uselog', 'column', 'user_id'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('user_uselog')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'start_time')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'user_uselog', 'column', 'start_time'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��ʼ�ϻ�ʱ��',
   'user', @CurrentUser, 'table', 'user_uselog', 'column', 'start_time'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('user_uselog')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'end_time')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'user_uselog', 'column', 'end_time'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�ϻ�����ʱ��',
   'user', @CurrentUser, 'table', 'user_uselog', 'column', 'end_time'
go

if exists(select 1 from sys.extended_properties p where
      p.major_id = object_id('user_uselog')
  and p.minor_id = (select c.column_id from sys.columns c where c.object_id = p.major_id and c.name = 'com_id')
)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description', 
   'user', @CurrentUser, 'table', 'user_uselog', 'column', 'com_id'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   'ʹ�õĵ���id',
   'user', @CurrentUser, 'table', 'user_uselog', 'column', 'com_id'
go

alter table class_uselog
   add constraint FK_CLASS_US_REFERENCE_TCLASS foreign key (class_id)
      references tclass (class_id)
go

alter table class_uselog
   add constraint FK_CLASS_US_REFERENCE_COMPUTER foreign key (room_id)
      references computer_room (room_id)
go

alter table computer
   add constraint FK_COMPUTER_REFERENCE_COMPUTER foreign key (room_id)
      references computer_room (room_id)
         on update cascade on delete cascade
go

alter table computer_room
   add constraint FK_COMPUTER_REFERENCE_DEPARTME foreign key (department)
      references department (department)
         on update cascade on delete cascade
go

alter table login_log
   add constraint FK_LOGIN_LO_REFERENCE_TUSER foreign key (user_id)
      references tuser (user_id)
go

alter table tclass
   add constraint FK_TCLASS_REFERENCE_DEPARTME foreign key (department)
      references department (department)
         on update cascade on delete cascade
go

alter table tuser
   add constraint FK_TUSER_REFERENCE_TCLASS foreign key (class_id)
      references tclass (class_id)
         on update cascade on delete cascade
go

alter table tuser
   add constraint FK_TUSER_REFERENCE_DEPARTME foreign key (department)
      references department (department)
go

alter table user_uselog
   add constraint FK_USER_USE_REFERENCE_TUSER foreign key (user_id)
      references tuser (user_id)
go

alter table user_uselog
   add constraint FK_USER_USE_REFERENCE_COMPUTER foreign key (com_id)
      references computer (com_id)
go




SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
USE CRMS
GO

--1�û����ڲ���󣬶�Ӧ�İ༶������1��
CREATE TRIGGER tuser_after_insert
   ON  tuser
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	declare @class_id varchar(50);
	select @class_id=class_id from inserted;
	update tclass set stu_num=stu_num+1 where class_id=@class_id;
END
GO

--2�û�����ɾ���󣬶�Ӧ�İ༶������1��
CREATE TRIGGER tuser_after_delete
   ON  tuser
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	declare @class_id varchar(50);
	select @class_id=class_id from deleted;
	update tclass set stu_num=stu_num-1 where class_id=@class_id;
END
GO

--3���Ա��ڲ���󣬶�Ӧ�Ļ�����������1��
CREATE TRIGGER computer_befor_insert
   ON  computer
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	declare @room_id varchar(50);
	select @room_id=room_id from inserted;
    update computer_room set com_num=com_num+1 where room_id=@room_id;
END
GO

--4���Ա���ɾ���󣬶�Ӧ�Ļ�����������1��
CREATE TRIGGER computer_befor_delete
   ON  computer
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
	declare @room_id varchar(50);
	select @room_id=room_id from deleted
    update computer_room set com_num=com_num-1 where room_id=@room_id;
END
GO


insert into department (department) values ('����Ա');
insert into tclass (name, department) values ('����Ա', '����Ա');

