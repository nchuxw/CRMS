package bean;

import java.util.Date;

public class ClassUseLog {
	
	private String classId;
	private Date startTime;
	private Date endTime;
	private String roomId;
	
	public ClassUseLog() {
		super();
	}
	
	public ClassUseLog(String classId, Date startTime, String roomId) {
		super();
		this.classId = classId;
		this.startTime = startTime;
		this.roomId = roomId;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}
}
