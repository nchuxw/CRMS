package bean;

public class ComputerBean {
	
	private String comId;
	private String roomId;
	private String comNo;
	private String satus;
	private int layoutX;
	private int layoutY;
	private String config;
	private String software;
	private String liabler;

	public ComputerBean() {
		super();
	}
	
	public ComputerBean(String comId, String roomId, String comNo, int layoutX, int layoutY) {
		super();
		this.comId = comId;
		this.roomId = roomId;
		this.comNo = comNo;
		this.layoutX = layoutX;
		this.layoutY = layoutY;
	}

	public String getComId() {
		return comId;
	}

	public void setComId(String comId) {
		this.comId = comId;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public String getComNo() {
		return comNo;
	}

	public void setComNo(String comNo) {
		this.comNo = comNo;
	}
	
	public String getSatus() {
		return satus;
	}

	public void setSatus(String satus) {
		this.satus = satus;
	}

	public int getLayoutX() {
		return layoutX;
	}

	public void setLayoutX(int layoutX) {
		this.layoutX = layoutX;
	}

	public int getLayoutY() {
		return layoutY;
	}

	public void setLayoutY(int layoutY) {
		this.layoutY = layoutY;
	}

	public String getConfig() {
		return config;
	}

	public void setConfig(String config) {
		this.config = config;
	}

	public String getSoftware() {
		return software;
	}

	public void setSoftware(String software) {
		this.software = software;
	}

	public String getLiabler() {
		return liabler;
	}

	public void setLiabler(String liabler) {
		this.liabler = liabler;
	}
}
