package bean;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.DBUtil;

public class ComputerRoomDao {
	
	public static ComputerRoomBean loadRoom(String roomId) throws SQLException {
		Connection con = DBUtil.getConnection("CRMS_admin", "admin");
		String sql = "select * from tuser where room_id='" + roomId + "'";
		System.out.println(sql);
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		if(rs.next()) {
			ComputerRoomBean room = new ComputerRoomBean();
			room.setRoomId(rs.getString("room_id"));
			room.setName(rs.getString("name"));
			room.setWidth(rs.getInt("width"));
			room.setHeight(rs.getInt("height"));
			room.setComNum(rs.getInt("com_num"));
			room.setUsableNum(rs.getInt("usable_num"));
			room.setUnuseTime(rs.getString("unuse_time"));
			room.setDepartment(rs.getString("department"));
			DBUtil.freeConnection(con);
			return room;
		}
		DBUtil.freeConnection(con);
		return null;
	}
	
}
