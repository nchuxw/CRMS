package bean;

import java.util.Date;

public class LoginLogBean {
	
	private String userId;
	private Date loginTime;
	private Date logoutTime;
	private String ipAdress;
	
	public LoginLogBean() {
		super();
	}

	public LoginLogBean(String userId, Date loginTime, String ipAdress) {
		super();
		this.userId = userId;
		this.loginTime = loginTime;
		this.ipAdress = ipAdress;
	}

	public LoginLogBean(String userId, Date loginTime, Date logoutTime, String ipAdress) {
		super();
		this.userId = userId;
		this.loginTime = loginTime;
		this.logoutTime = logoutTime;
		this.ipAdress = ipAdress;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}

	public Date getLogoutTime() {
		return logoutTime;
	}

	public void setLogoutTime(Date logoutTime) {
		this.logoutTime = logoutTime;
	}

	public String getIpAdress() {
		return ipAdress;
	}

	public void setIpAdress(String ipAdress) {
		this.ipAdress = ipAdress;
	}
}
