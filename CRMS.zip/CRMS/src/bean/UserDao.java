package bean;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.DBUtil;

public class UserDao {
	
	public static UserBean loadUser(String userId) throws SQLException {
		Connection con = DBUtil.getConnection("CRMS_admin", "admin");
		String sql = "select * from tuser where user_id='" + userId + "'";
		System.out.println(sql);
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		if(rs.next()) {
			UserBean user = new UserBean();
			user.setUserId(rs.getString("user_id"));
			user.setPassword(rs.getString("password"));
			user.setType(rs.getString("type"));
			user.setName(rs.getString("name"));
			user.setClassId(rs.getString("class_id"));
			user.setDepartment(rs.getString("department"));
			DBUtil.freeConnection(con);
			return user;
		}
		DBUtil.freeConnection(con);
		return null;
	}
	
}
