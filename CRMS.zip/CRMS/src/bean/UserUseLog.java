package bean;

import java.util.Date;

public class UserUseLog {
	
	private String userId;
	private Date startTime;
	private Date endTime;
	private String comId;
	
	public UserUseLog() {
		super();
	}
	
	public UserUseLog(String userId, Date startTime, String comId) {
		super();
		this.userId = userId;
		this.startTime = startTime;
		this.comId = comId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getComId() {
		return comId;
	}

	public void setComId(String comId) {
		this.comId = comId;
	}
}
